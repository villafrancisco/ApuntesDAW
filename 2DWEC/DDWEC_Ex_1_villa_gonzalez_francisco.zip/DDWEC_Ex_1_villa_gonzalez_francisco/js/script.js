

function mostrarAutobusesPlazasLibres(flota){
    //console.log(flota.getNumeroAutobuses());
    
    var fragmento="<table><tr><td>Matricula</td><td>Numero plazas libres</td></tr>";
    for(var i=0;i<flota.getNumeroAutobuses();i++){
        var plazaslibres=parseInt(flota.getAutobuses()[i].getplazasTotales())-parseInt(flota.getAutobuses()[i].getplazasOcupadas());
        fragmento+="<tr><td>"+flota.getAutobuses()[i].getMatricula()+"</td><td>"+plazaslibres+"</td>";
    }
    fragmento+="</table>";
    var tablaplazaslibres=document.getElementById("aplazaslibres");
    tablaplazaslibres.innerHTML=fragmento;
}

function mostrartodosAutobuses(flota){
    var tablatodos=document.getElementById("todos");
    todos.innerHTML=flota.toHTML();
}


//He metido todos los datos por aqui, porque si no, no me daba tiempo

//var Autobus1=new Autobus(matricula,origen,destino,fecha,numeroFilas,precioBase);
var autobus1=new Autobus("pod-9856","Santander","Torrelavega","27-05-1986",10,50);
var autobus2=new Autobus("xxx-9856","Madrid","Bilbao","11-01-1986",17,100);
var autobus3=new Autobus("yyyy-9856","Barcelona","Oviedo","11-05-1999",12,100);

autobus1.setplazasTotales(101);
autobus1.setplazasOcupadas(3);
autobus1.setprecioBase(10);


autobus2.setplazasTotales(151);
autobus2.setplazasOcupadas(51);
autobus2.setprecioBase(12);


autobus3.setplazasTotales(251);
autobus3.setplazasOcupadas(21);
autobus3.setprecioBase(12);


var flota1=new Flota();
flota1.addAutobus(autobus1);
flota1.addAutobus(autobus2);
flota1.addAutobus(autobus3);


mostrarAutobusesPlazasLibres(flota1);
mostrartodosAutobuses(flota1);
var numautobuses=document.getElementById("numautobuses");
numautobuses.innerHTML="Número de autobuses "+ flota1.getNumeroAutobuses();

