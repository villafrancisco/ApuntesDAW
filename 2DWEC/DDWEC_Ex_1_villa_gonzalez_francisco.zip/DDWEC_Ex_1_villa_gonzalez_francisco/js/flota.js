
/* 
 Definición de la clase flota
 */

//Clase Flota
function Flota(){
    this._autobuses=[];
}

Flota.prototype.getAutobuses=function(){
    return this._autobuses;
}
Flota.prototype.setAutobuses=function(autobuses){
    this._autobuses=autobuses;
}

Flota.prototype.addAutobus = function(autobus) {
    //si existe el autobus con esa matricula en el array de autobuses
    console.log(this._autobuses.length);
    if(this._autobuses.length==0){
        this._autobuses.push(autobus);
        return true;
    }
    for(var i=0;i<this._autobuses.length;i++){
        if(this._autobuses[i].matricula==autobus.matricula){
            //Existe ese autobus con esa matricula
            return false;
        }else{
            this._autobuses.push(autobus);
            return true;
        }
    }
    
}

Flota.prototype.getAutobus = function(origen,destino) {
    var encontrado=false;
    for(var i=0;i<this._autobuses.length;i++){
        if(this._autobuses[i].origen==origen && this._autobuses[i].destino==destino){
            encontrado=true;
            return this._autobuses[i];
        }
    }
    if(encotrado==false){
        return null;
    }
}


Flota.prototype.getNumeroAutobuses = function() {
    return this._autobuses.length;
}


Flota.prototype.toHTML = function() {
    var fragmento="<table>";
    fragmento+="<tr><td>Matricula</td><td>Origen</td><td>Destino</td><td>fecha</td><td>Precio base</td><td>Plazas autobus</td><td>Plazas Ocupadas</td><td>Numero Filas</td></tr>";
    for(var i=0;i<this._autobuses.length;i++){
        fragmento+="<tr><td>"+this._autobuses[i].matricula+"</td><td>"+this._autobuses[i].origen+"</td><td>"+this._autobuses[i].destino+"</td><td>"+this._autobuses[i].fecha+"</td><td>"+this._autobuses[i]._precioBase+"</td><td>"+this._autobuses[i]._plazasTotales+"</td><td>"+this._autobuses[i]._plazasOcupadas+"</td><td>"+this._autobuses[i]._numeroFilas+"</td></tr>";
    }
    fragmento+="</table>";

    return fragmento;
}




