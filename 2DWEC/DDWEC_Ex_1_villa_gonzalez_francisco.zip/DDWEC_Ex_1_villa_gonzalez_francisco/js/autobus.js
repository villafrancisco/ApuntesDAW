/* 
 Definición de la clase autobus
 */

//Clase Autobus 
function Autobus(matricula,origen,destino,fecha,numeroFilas,precioBase){
    this.matricula=matricula;
    this.origen=origen;
    this.destino=destino;
    this.fecha=fecha;
    this._precioBase=precioBase;
    this._numeroFilas=numeroFilas;
    this._plazasTotales;
    this._plazasOcupadas;
}

Autobus.prototype.getMatricula=function(){
    return this.matricula;
}
Autobus.prototype.setMatricula=function(matricula){
    this.matricula=matricula;
}

Autobus.prototype.getOrigen=function(){
    return this.origen;
}
Autobus.prototype.setOrigen=function(origen){
    this.origen=origen;
}

Autobus.prototype.getDestino=function(){
    return this.destino;
}
Autobus.prototype.setDestino=function(destino){
    this.destino=destino;
}

Autobus.prototype.getFecha=function(){
    return this.fecha;
}
Autobus.prototype.setFecha=function(nombfechare){
    this.fecha=fecha;
}

Autobus.prototype.getprecioBase=function(){
    return this._precioBase;
}
Autobus.prototype.setprecioBase=function(precioBase){
    this._precioBase=precioBase;
}

Autobus.prototype.getnumeroFilas=function(){
    return this._numeroFilas;
}
Autobus.prototype.setnumeroFilas=function(numeroFilas){
    this._numeroFilas=numeroFilas;
}

Autobus.prototype.getplazasTotales=function(){
    return this._plazasTotales;
}
Autobus.prototype.setplazasTotales=function(plazasTotales){
    this._plazasTotales=plazasTotales;
}

Autobus.prototype.getplazasOcupadas=function(){
    return this._plazasOcupadas;
}
Autobus.prototype.setplazasOcupadas=function(plazasOcupadas){
    this._plazasOcupadas=plazasOcupadas;
}

Autobus.prototype.generaPrecio = function() {
    var precio=0;
    for(var i=0;i<this._plazasOcupadas;i++){
        precio=precio+0.2;
    }
    precio=precio+parseInt(this._precioBase);
    
    return precio;
}

Autobus.prototype.ventaBilletes = function(nbilletes) {
    if(parseInt(this._plazasOcupadas)<parseInt(this._plazasTotales)){
        //Hay plazas disponibles
        this._plazasOcupadas=this._plazasOcupadas+nbilletes;
        return this.generaPrecio()*nbilletes;
    }else{
        //no hay plazas libres
        return 0;
    }
    
}

Autobus.prototype.getPorcentajeOcupacion = function() {
    var pocentaje;
    porcentaje=parseInt(this._plazasOcupadas)/parseInt(this._plazasTotales)*100;
    return porcentaje.toFixed();
}



